///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// Scene geometry, textures, materials, and lighting.
// Original course framework by Brian Battersby, SNHU (2023).
///////////////////////////////////////////////////////////////////////////////
#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <cstdint>
#include <string>
#include <vector>

class SceneManager
{
public:
	SceneManager(ShaderManager* pShaderManager);
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID = 0;
	};

	struct OBJECT_MATERIAL
	{
		glm::vec3 diffuseColor = glm::vec3(0.0f);
		glm::vec3 specularColor = glm::vec3(0.0f);
		float shininess = 0.0f;
		std::string tag;
	};

	void PrepareScene();
	void RenderScene();

private:
	ShaderManager* m_pShaderManager;
	ShapeMeshes* m_basicMeshes;
	int m_loadedTextures;
	TEXTURE_INFO m_textureIDs[16];
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	bool CreateGLTexture(const char* filename, std::string tag);
	void BindGLTextures();
	void DestroyGLTextures();
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);
	void LoadSceneTextures();
	void DefineObjectMaterials();
	void SetupSceneLights();
	void SetTransformations(glm::vec3 scaleXYZ, float XrotationDegrees,
		float YrotationDegrees, float ZrotationDegrees, glm::vec3 positionXYZ);
	void SetShaderColor(float redColorValue, float greenColorValue,
		float blueColorValue, float alphaValue);
	void SetShaderTexture(std::string textureTag);
	void SetTextureUVScale(float u, float v);
	void SetShaderMaterial(std::string materialTag);
};
