///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// Camera movement, mouse callbacks, and projection selection.
// Original course framework by Brian Battersby, SNHU (2023).
///////////////////////////////////////////////////////////////////////////////
#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include "GLFW/glfw3.h"

class ViewManager
{
public:
	ViewManager(ShaderManager* pShaderManager);
	~ViewManager();

	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

	GLFWwindow* CreateDisplayWindow(const char* windowTitle);
	void PrepareSceneView();

private:
	void ProcessKeyboardEvents();

	ShaderManager* m_pShaderManager;
	GLFWwindow* m_pWindow;
};
