///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// Camera navigation and perspective/orthographic display.
// Original course framework by Brian Battersby, SNHU (2023).
///////////////////////////////////////////////////////////////////////////////
#include "ViewManager.h"

#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace
{
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	Camera* g_pCamera = nullptr;
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;
	bool bOrthographicProjection = false;
}

ViewManager::ViewManager(ShaderManager* pShaderManager)
	: m_pShaderManager(pShaderManager), m_pWindow(nullptr)
{
	g_pCamera = new Camera();
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80.0f;
	g_pCamera->MovementSpeed = 10.0f;
}

ViewManager::~ViewManager()
{
	delete g_pCamera;
	g_pCamera = nullptr;
	m_pWindow = nullptr;
	m_pShaderManager = nullptr;
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = glfwCreateWindow(
		WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, nullptr, nullptr);
	if (window == nullptr)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return nullptr;
	}

	glfwMakeContextCurrent(window);
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	m_pWindow = window;
	return window;
}

void ViewManager::Mouse_Position_Callback(GLFWwindow* window,
	double xMousePos, double yMousePos)
{
	(void)window;
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	const float xOffset = static_cast<float>(xMousePos) - gLastX;
	const float yOffset = gLastY - static_cast<float>(yMousePos);
	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);
	if (g_pCamera != nullptr)
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window,
	double xOffset, double yOffset)
{
	(void)window;
	(void)xOffset;
	if (g_pCamera == nullptr)
		return;

	g_pCamera->MovementSpeed += static_cast<float>(yOffset);
	if (g_pCamera->MovementSpeed < 1.0f)
		g_pCamera->MovementSpeed = 1.0f;
	if (g_pCamera->MovementSpeed > 25.0f)
		g_pCamera->MovementSpeed = 25.0f;
}

void ViewManager::ProcessKeyboardEvents()
{
	if (m_pWindow == nullptr || g_pCamera == nullptr)
		return;

	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(m_pWindow, true);

	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

	// Q/E move along the world's vertical axis, independent of camera pitch.
	const glm::vec3 worldUp(0.0f, 1.0f, 0.0f);
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
		g_pCamera->Position += worldUp * g_pCamera->MovementSpeed * gDeltaTime;
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
		g_pCamera->Position -= worldUp * g_pCamera->MovementSpeed * gDeltaTime;

	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
		bOrthographicProjection = false;
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
		bOrthographicProjection = true;
}

void ViewManager::PrepareSceneView()
{
	if (g_pCamera == nullptr)
		return;

	const float currentFrame = static_cast<float>(glfwGetTime());
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;
	ProcessKeyboardEvents();

	// Both displays use the same camera position and orientation.
	const glm::mat4 view = g_pCamera->GetViewMatrix();
	const glm::mat4 projection = bOrthographicProjection
		? glm::ortho(-10.0f, 10.0f, -8.0f, 8.0f, 0.1f, 100.0f)
		: glm::perspective(glm::radians(g_pCamera->Zoom),
			static_cast<float>(WINDOW_WIDTH) / static_cast<float>(WINDOW_HEIGHT),
			0.1f, 100.0f);

	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setMat4Value("view", view);
		m_pShaderManager->setMat4Value("projection", projection);
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}
