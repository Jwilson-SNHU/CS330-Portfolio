///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Start with no textures loaded.
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/***********************************************************
 * LoadSceneTextures()
 *
 * Loads and binds the textures used by the desk and monitor.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// Load the tiled wooden desk texture.
	CreateGLTexture(
		"textures/wood_cherry_seamless.jpg",
		"deskWood");

	// Load the metal monitor-stand texture.
	CreateGLTexture(
		"textures/metal_galvanized_seamless.jpg",
		"standMetal");

	// Load the dark plastic monitor texture.
	CreateGLTexture(
		"textures/plastic_dark_seamless.jpg",
		"monitorPlastic");

	// Load the image displayed on the monitor screen.
	CreateGLTexture(
		"textures/screen_wallpaper_1.jpg",
		"screenWallpaper");

	// Bind all loaded textures to OpenGL texture slots.
	BindGLTextures();
}
/***********************************************************
 * DefineObjectMaterials()
 *
 * Defines how the textured surfaces reflect light.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	// Wood keeps its texture color with a subtle surface sheen.
	OBJECT_MATERIAL wood{};
	wood.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	wood.specularColor = glm::vec3(0.18f, 0.18f, 0.18f);
	wood.shininess = 16.0f;
	wood.tag = "wood";
	m_objectMaterials.push_back(wood);

	// Metal produces stronger, more focused highlights.
	OBJECT_MATERIAL metal{};
	metal.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	metal.specularColor = glm::vec3(0.70f, 0.70f, 0.70f);
	metal.shininess = 48.0f;
	metal.tag = "metal";
	m_objectMaterials.push_back(metal);

	// Dark plastic has softer highlights than the metal stand.
	OBJECT_MATERIAL plastic{};
	plastic.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	plastic.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	plastic.shininess = 24.0f;
	plastic.tag = "plastic";
	m_objectMaterials.push_back(plastic);

	// Keep the wallpaper visible without a strong reflected glare.
	OBJECT_MATERIAL screen{};
	screen.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screen.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	screen.shininess = 32.0f;
	screen.tag = "screen";
	m_objectMaterials.push_back(screen);

	OBJECT_MATERIAL ceramic{};
	ceramic.diffuseColor = glm::vec3(0.93f, 0.93f, 0.90f);
	ceramic.specularColor = glm::vec3(0.52f, 0.52f, 0.52f);
	ceramic.shininess = 32.0f;
	ceramic.tag = "ceramic";
	m_objectMaterials.push_back(ceramic);

	OBJECT_MATERIAL paper{};
	paper.diffuseColor = glm::vec3(0.83f, 0.80f, 0.69f);
	paper.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	paper.shininess = 4.0f;
	paper.tag = "paper";
	m_objectMaterials.push_back(paper);
}

/***********************************************************
 * SetupSceneLights()
 *
 * Uses a white overhead light and a purple fill light.
 ***********************************************************/

void SceneManager::SetupSceneLights()
{
	// Disable light sources that are not used in this scene.
	m_pShaderManager->setBoolValue("directionalLight.bActive", false);
	m_pShaderManager->setBoolValue("spotLight.bActive", false);
	m_pShaderManager->setBoolValue("pointLights[4].bActive", false);

	// Main light above and in front of the monitor and desk.
	m_pShaderManager->setVec3Value(
		"pointLights[0].position", 4.0f, 10.0f, 8.0f);
	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient", 0.20f, 0.20f, 0.20f);
	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse", 0.70f, 0.70f, 0.70f);
	m_pShaderManager->setVec3Value(
		"pointLights[0].specular", 0.60f, 0.60f, 0.60f);
	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive", true);

	// Purple fill light behind and to the left of the monitor.
	// Ambient light keeps surfaces facing away from both lights visible.
	m_pShaderManager->setVec3Value(
		"pointLights[1].position", -5.0f, 7.0f, -4.0f);
	m_pShaderManager->setVec3Value(
		"pointLights[1].ambient", 0.06f, 0.04f, 0.08f);
	m_pShaderManager->setVec3Value(
		"pointLights[1].diffuse", 0.25f, 0.12f, 0.35f);
	m_pShaderManager->setVec3Value(
		"pointLights[1].specular", 0.30f, 0.15f, 0.40f);
	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive", true);

	// A soft front-left fill light reaches the keyboard and notebook.
	m_pShaderManager->setVec3Value(
		"pointLights[2].position", -7.0f, 6.0f, 7.0f);
	m_pShaderManager->setVec3Value(
		"pointLights[2].ambient", 0.08f, 0.08f, 0.08f);
	m_pShaderManager->setVec3Value(
		"pointLights[2].diffuse", 0.35f, 0.35f, 0.35f);
	m_pShaderManager->setVec3Value(
		"pointLights[2].specular", 0.18f, 0.18f, 0.18f);
	m_pShaderManager->setBoolValue(
		"pointLights[2].bActive", true);

	// A gentle rear-right fill prevents the mug and monitor sides
	// from disappearing when viewed from behind.
	m_pShaderManager->setVec3Value(
		"pointLights[3].position", 7.0f, 7.0f, -6.0f);
	m_pShaderManager->setVec3Value(
		"pointLights[3].ambient", 0.07f, 0.07f, 0.07f);
	m_pShaderManager->setVec3Value(
		"pointLights[3].diffuse", 0.30f, 0.30f, 0.30f);
	m_pShaderManager->setVec3Value(
		"pointLights[3].specular", 0.18f, 0.18f, 0.18f);
	m_pShaderManager->setBoolValue(
		"pointLights[3].bActive", true);

	// Enable ambient, diffuse, and specular lighting.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load and bind the existing scene textures.
	LoadSceneTextures();

	// Load each mesh once for reuse during rendering.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadCylinderMesh();

	// Define materials before configuring the lighting.
	DefineObjectMaterials();
	SetupSceneLights();
}

/***********************************************************
 * RenderScene()
 *
 * Constructs and textures a computer monitor from multiple
 * primitive shapes positioned on a tiled wooden desk.
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Create the wooden desk surface.
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderTexture("deskWood");
	SetShaderMaterial("wood");

	// Repeat the seamless texture to avoid stretching it.
	SetTextureUVScale(5.0f, 3.0f);
	m_basicMeshes->DrawPlaneMesh();

	// Create the metal base of the monitor stand.
	scaleXYZ = glm::vec3(4.2f, 0.35f, 2.0f);
	positionXYZ = glm::vec3(0.0f, 0.175f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		10.0f,
		0.0f,
		positionXYZ);

	SetShaderTexture("standMetal");
	SetShaderMaterial("metal");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Create the tapered metal support.
	scaleXYZ = glm::vec3(1.3f, 2.8f, 0.55f);
	positionXYZ = glm::vec3(0.0f, 0.35f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		10.0f,
		0.0f,
		positionXYZ);

	SetShaderTexture("standMetal");
	SetShaderMaterial("metal");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Create the dark plastic monitor frame.
	scaleXYZ = glm::vec3(8.0f, 4.6f, 0.50f);
	positionXYZ = glm::vec3(0.0f, 5.45f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		10.0f,
		0.0f,
		positionXYZ);

	SetShaderTexture("monitorPlastic");
	SetShaderMaterial("plastic");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// Position the thin screen box in front of the frame.
	scaleXYZ = glm::vec3(7.25f, 3.85f, 0.12f);
	positionXYZ = glm::vec3(0.05f, 5.55f, 0.31f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		10.0f,
		0.0f,
		positionXYZ);

	// Apply the wallpaper texture and screen material.
	SetShaderTexture("screenWallpaper");
	SetShaderMaterial("screen");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Keyboard body in front of the monitor: dark plastic reuses
	// the existing texture and material without another image file.
	SetTransformations(glm::vec3(6.2f, 0.18f, 1.65f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.09f, 3.35f));
	SetShaderTexture("monitorPlastic");
	SetShaderMaterial("plastic");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Distinct low-profile keys make the keyboard readable from above.
	for (int row = 0; row < 3; ++row)
	{
		for (int column = 0; column < 11; ++column)
		{
			const float keyX = -2.72f + 0.54f * column;
			const float keyZ = 2.85f + 0.47f * row;
			SetTransformations(glm::vec3(0.43f, 0.07f, 0.34f),
				0.0f, 0.0f, 0.0f,
				glm::vec3(keyX, 0.22f, keyZ));
			SetShaderTexture("monitorPlastic");
			SetShaderMaterial("plastic");
			SetTextureUVScale(1.0f, 1.0f);
			m_basicMeshes->DrawBoxMesh();
		}
	}

	// Notebook on the left. The pale paper lies just above its cover.
	SetTransformations(glm::vec3(2.1f, 0.12f, 2.75f),
		0.0f, -15.0f, 0.0f, glm::vec3(-5.4f, 0.06f, 2.2f));
	SetShaderTexture("monitorPlastic");
	SetShaderMaterial("plastic");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	SetTransformations(glm::vec3(1.88f, 0.035f, 2.53f),
		0.0f, -15.0f, 0.0f, glm::vec3(-5.4f, 0.138f, 2.2f));
	SetShaderColor(0.94f, 0.91f, 0.82f, 1.0f);
	SetShaderMaterial("paper");
	m_basicMeshes->DrawBoxMesh();

	// Ceramic mug on the right: body, dark inset, and three-part handle.
	SetTransformations(glm::vec3(0.66f, 1.18f, 0.66f),
		0.0f, 0.0f, 0.0f, glm::vec3(5.4f, 0.0f, 1.5f));
	SetShaderColor(0.90f, 0.90f, 0.86f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawCylinderMesh();

	// A dark, inset top suggests the inside of the cup without
	// adding high-polygon geometry.
	SetTransformations(glm::vec3(0.53f, 0.015f, 0.53f),
		0.0f, 0.0f, 0.0f, glm::vec3(5.4f, 1.188f, 1.5f));
	SetShaderColor(0.11f, 0.10f, 0.10f, 1.0f);
	SetShaderMaterial("plastic");
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	const glm::vec3 handleScale[] = {
		glm::vec3(0.72f, 0.13f, 0.16f),
		glm::vec3(0.72f, 0.13f, 0.16f),
		glm::vec3(0.15f, 0.65f, 0.16f)
	};
	const glm::vec3 handlePosition[] = {
		glm::vec3(6.13f, 0.93f, 1.5f),
		glm::vec3(6.13f, 0.35f, 1.5f),
		glm::vec3(6.45f, 0.64f, 1.5f)
	};
	for (int part = 0; part < 3; ++part)
	{
		SetTransformations(handleScale[part], 0.0f, 0.0f,
			0.0f, handlePosition[part]);
		SetShaderColor(0.90f, 0.90f, 0.86f, 1.0f);
		SetShaderMaterial("ceramic");
		m_basicMeshes->DrawBoxMesh();
	}
}
